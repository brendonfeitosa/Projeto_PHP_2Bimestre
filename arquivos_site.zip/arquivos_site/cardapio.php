<?php require_once("header.php"); ?>
<div class="container-fluid col-11 m-auto">
    <h1>Cardápio</h1>
    <hr>

    <form action="verificar_pedido.php" method="get">
        <div class="text-justify">
            <div>
                <h2 id="massas">Massas</h2>
                <hr>
                <h3>Macarão xxx</h3>
                <img src="./img/massa1.jpg" class="img-thumbnail float-end" alt="...">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi voluptas delectus in ipsum recusandae placeat iure odio dolor ab magnam illo, adipisci modi voluptatibus doloribus, eius asperiores ratione beatae. Quasi. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nobis saepe tempora reiciendis assumenda molestias consequatur dignissimos quisquam, ad maiores nisi aspernatur fuga sit? Non consectetur impedit architecto culpa, illum ipsa.</p>
                <div class="d-grid gap-2 d-md-block">
                    <button class="btn btn-primary" type="button">Adicionar</button>
                </div>
                <br><br><br><br><br><br><br><br><br><br><!-- gambiarra, precisamos arrumar -->
            </div>
            <div>
                <h2 id="pizzas">Pizzas</h2>
                <hr>
                <h3>Pizza xxx</h3>
                <img src="./img/pizza2.jpg" class="img-thumbnail float-end" alt="...">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi voluptas delectus in ipsum recusandae placeat iure odio dolor ab magnam illo, adipisci modi voluptatibus doloribus, eius asperiores ratione beatae. Quasi. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nobis saepe tempora reiciendis assumenda molestias consequatur dignissimos quisquam, ad maiores nisi aspernatur fuga sit? Non consectetur impedit architecto culpa, illum ipsa.</p>
                <div class="d-grid gap-2 d-md-block">
                    <button class="btn btn-primary" type="button">Adicionar</button>
                </div>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><!-- gambiarra, precisamos arrumar -->
            </div>
            <div>
                <h2 id="bebidas">Bebidas</h2>
                <hr>
                <h3>Bebida xxx</h3>
                <img src="./img/coca-cola-lata-350ml-min.png" class="img-thumbnail float-end" alt="...">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi voluptas delectus in ipsum recusandae placeat iure odio dolor ab magnam illo, adipisci modi voluptatibus doloribus, eius asperiores ratione beatae. Quasi. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nobis saepe tempora reiciendis assumenda molestias consequatur dignissimos quisquam, ad maiores nisi aspernatur fuga sit? Non consectetur impedit architecto culpa, illum ipsa.</p>
                <div class="d-grid gap-2 d-md-block">
                    <button class="btn btn-primary" type="button">Adicionar</button>
                </div>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><!-- gambiarra, precisamos arrumar -->
            </div>
            <div>
                <h2 id="sobremesas">Sobremesas</h2>
                <hr>
                <h3>Sobremesa xxx</h3>
                <img src="./img/pudim2.jpg" class="img-thumbnail float-end" alt="...">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi voluptas delectus in ipsum recusandae placeat iure odio dolor ab magnam illo, adipisci modi voluptatibus doloribus, eius asperiores ratione beatae. Quasi. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nobis saepe tempora reiciendis assumenda molestias consequatur dignissimos quisquam, ad maiores nisi aspernatur fuga sit? Non consectetur impedit architecto culpa, illum ipsa.</p>
                <div class="d-grid gap-2 d-md-block">
                    <button class="btn btn-primary" type="button">Adicionar</button>
                </div>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br> <!-- gambiarra, precisamos arrumar -->
            </div>
            <button type="submit" class="btn btn-primary">Verificar pedido</button>
    </form>


    </div>


</div>



<?php require_once("footer.php") ?>