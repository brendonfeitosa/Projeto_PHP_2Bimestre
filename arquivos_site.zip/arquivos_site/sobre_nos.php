<?php require_once("header.php"); ?>


<div class="container-fluid col-11 m-auto">
    <h1>Conheça nossa história</h1>
    <hr>
    <div class="text-justify m-auto">
        <h2>Fundação</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum quas distinctio numquam suscipit explicabo corporis amet dolores voluptatibus harum. Tempore consequuntur commodi aliquam dolores corporis laboriosam quas earum suscipit optio.</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Modi nam quasi, qui labore placeat quas nemo soluta laudantium tenetur nulla saepe porro eum adipisci maxime neque provident. Velit, error quia.</p>
        <h2>De onde viemos</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. In accusantium nobis adipisci, soluta excepturi rerum officiis dolorem culpa ut alias corporis necessitatibus. Voluptatibus, voluptatum accusamus minus quam pariatur provident porro?</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At aliquam reprehenderit consequatur beatae debitis! Quaerat facilis perspiciatis similique consequatur dolores cum deleniti. Possimus vitae distinctio quo qui, nisi a rem.</p>
        <h2>Porque escolhemos esta cidade?</h2>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Corporis amet nemo repellat iusto ducimus voluptatum aut laudantium modi inventore assumenda quaerat sint dignissimos sapiente ipsa aliquid quis, eum quidem aliquam.</p>
    </div>
</div>
<?php require_once("footer.php") ?>